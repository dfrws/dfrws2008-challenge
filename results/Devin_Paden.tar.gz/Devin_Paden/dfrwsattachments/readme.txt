archive.zip was recovered from suspect.pcap using parsecookies.rb.  The password is 'rhubarb'
gnometimes.txt is sample output from the grep command in figure 24
parsecookies.rb processes pdml output from the tshark readfilter (see comments in source code)
scalpel.conf is updated to include the entries used in this investigation (they are at the bottom)
testgnomeids.rb shows the relationship in time between gnome and nautilus launched applications
timestamps.txt is sample output from the grep command in figure 20
content_encoding_gzip.rtf contains excerpts from gzip encoded http responses frog mail.google.com that show collaboration.
Regards,
Devin Paden 3/31/2008
