The Johns Hopkins University
Applied Physics Laboratory
11100 Johns Hopkins Rd
Laurel MD 20723-6099

This submission is provided by the Johns Hopkins University Applied Physics
Laboratory (JHU/APL).  JHU/APL is a not-for-profit center for engineering,
research and development for government sponsors and business partners,
designated as a University-Affiliated Research Center.  For more information
visit http://www.jhuapl.com/.

The JHU/APL DFRWS Challenge team members are listed below:

POC:
Donna C. Paulhamus
Donna.Paulhamus@jhuapl.edu
Ph. 443-778-8362
Fax 443-778-4140

Rodney M. Jokerst
Yanni A. Kouskoulas
Karla J. Saur
Kevin Z. Snow
Brian M. Whipple
